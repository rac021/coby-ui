


  const appName = 'Coby 2.0' ;
 
  const onRecievedDataLogsEvent = 'on-recieved-data-logs-event' ;

  const onRecievedDataJobsEvent = 'on-recieved-data-jobs-event' ;

  const onSubmitJobEvent = "on-submit-job-event" ;

  const onClearLogs = "on-clear-logs" ;

  const onJobsEvent = "jobs" ;

  const onLogsEvent = "logs" ;

  const onClearLogsEvent = "clear-logs" ;


